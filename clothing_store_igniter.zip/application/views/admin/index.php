
            <div id="chart" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

