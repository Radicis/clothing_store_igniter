<?php $this->load->view('includes/header' ,$this->globals);?>

<?php $this->load->view($main_content);?>

<?php $this->load->view('includes/footer');?>
