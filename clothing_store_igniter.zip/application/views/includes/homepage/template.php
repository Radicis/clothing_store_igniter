<?php $this->load->view('includes/homepage/header', $this->globals);?>

<?php $this->load->view($main_content);?>

<?php $this->load->view('includes/homepage/footer');?>
